package com.example.myapplication;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        TimePicker timePicker = findViewById(R.id.picktime);
        ImageView analogClock = findViewById(R.id.clockAnalog);

        Calendar calendar = Calendar.getInstance();
        View root = findViewById(R.id.main);

        int hour1 = calendar.get(Calendar.HOUR_OF_DAY);

        if (hour1 >= 8 && hour1 < 18){
            analogClock.setImageResource(R.drawable.sun);
            root.setBackgroundResource(R.drawable.sky);
        } else {
            analogClock.setImageResource(R.drawable.moon);
            root.setBackgroundResource(R.drawable.nightsky);
        }

        button.setOnClickListener(v -> {
            int hour = timePicker.getHour();
                if (hour >= 8 && hour < 18) {
                    analogClock.setImageResource(R.drawable.sun);
                    root.setBackgroundResource(R.drawable.sky);
                    ViewCompat.setBackgroundTintList(button, ColorStateList.valueOf(Color.parseColor("#FDBE90")));
                } else {
                    analogClock.setImageResource(R.drawable.moon);
                    root.setBackgroundResource(R.drawable.nightsky);
                    ViewCompat.setBackgroundTintList(button, ColorStateList.valueOf(Color.parseColor("#BFCFDA")));
                }});
            };}